<?php
Class Model_login extends CI_Model {
	public function login() {
		$data=$this->input->post();
		$sql="select * from web_pelanggan where userID='$data[txtuserid]' and PASSWORD=md5('$data[txtpassword]')";

		$query = $this->db->query($sql);
		//echo $query->num_rows(); exit();
		if ($query->num_rows() == 1) {
			return true;
		} else {
			return false;
		}
	}

	public function read_user($userid) {
		$sql="select * from web_pelanggan where userID='$userid'";
		$query = $this->db->query($sql);
		if ($query->num_rows() == 1) {
			return $query->result();
		} else {
			return false;
		}
	}

	public function registrasi_save(){
		$post = $this->input->post();
		$sql="insert into web_pelanggan(nama,userid, email,password) values ('$post[txtuserid]','$post[txtuserid]','$post[txtemail]',md5('$post[txtpassword]'))";
		$this->db->query($sql);
	}
}