<?php

defined('BASEPATH') OR exit('No direct script access allowed');

    class Login extends CI_Controller {
        public function index(){
            $this->load->view('header');
            $this->load->view('login_form');
            $this->load->view('footer');
        }
        public function login_proses(){
            $this->load->model("Model_login");
            $result = $this->Model_login->login();
            echo $result;
            if ($result == TRUE) {
                $userid = $this->input->post('txtuserid');
                $result = $this->Model_login->read_user($userid);
                if ($result != false) {
                    $session_data = array(
                        'id' => $result[0]->id,
                        'userid' => $result[0]->userID,
                        'username' => $result[0]->nama,
                        'email' => $result[0]->email,
                    );
                // Add user data in session
                $this->session->set_userdata('logged_in',
                $session_data);
                //$this->load->view('home');
                redirect(site_url().'/home');
            }
        } else {
            $data = array('message_display' => 'Invalid Username or Password');
            $this->load->view('header');
            $this->load->view('login_form',$data);
            $this->load->view('footer');
        }
    }

    public function registrasi(){
        $this->load->view('header');
        $this->load->view('registrasi');
        $this->load->view('footer');
    }

    public function registrasi_proses(){
        $post=$this->input->post();
        $valid=true;
        $teks['message']="";
        $this->load->model("Model_pelanggan");
        $data=$this->Model_pelanggan->get_pelanggan_byuserid($post['txtuserid']);
        if($data){
        $valid=false;
        $teks['message']="* Username sudah ada, silahkan gunakan username yang lain<br>";
    }

    if($post['txtpassword']!=$post['txtkonfirmasi']){
        $valid=false;
        $teks['message']=$teks['message']."* Password dan konfirmasi tidak sama<br>";    
    }
    
    if($valid==false){
        $this->load->view('header');
        $this->load->view('registrasi',$teks);
        $this->load->view('footer');
    }else{    
        $this->load->model("Model_login");
        $this->Model_login->registrasi_save();
        $this->load->view('header');
        $this->load->view('login_form');
        $this->load->view('footer');
    }
}

    public function logout() {
        // Removing session data
        $sess_array = array(
            'userid' => '',
            'username' => '',
            'email' => '',
        );
        $this->session->unset_userdata('logged_in', $sess_array);
        $data['message_display'] = 'Successfully Logout';
        $this->load->view('header');
        $this->load->view('login_form',$data);
        $this->load->view('footer');
    }
}
//end class Login