<main>
<!-- Hero Area Start-->
        <div class="slider-area ">
            <div class="single-slider slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap text-center">
                                <h2>Cart List</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero Area End-->
      </main>
      <!--================Cart Area =================-->
      <section class="cart_area section_padding">
        <div class="container">
          <div class="cart_inner">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Image</th>
                    <th scope="col">Merk</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total Pay</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $total=0;
                      foreach ($cart_list as $cart) {
                        $total=$total+$cart['subtotal'];
                  ?>
                  <tr>
                    <td>
                        <img src="<?php echo base_url().'/product/'.$cart['image'] ?>" width="100" height="100">
                    </td>
                    <td>
                      <h5><?php echo substr($cart['name'],0,40); ?></h5>
                    </td>
                    <td>
                      <span>Rp. <?php echo number_format($cart['price'],2,',','.'); ?></span>
                    </td>
                    <td>
                      <div class="product_count">
                        <span> <?php echo $cart['qty'];?></span>
                      </div>
                    </td>
                    <td>
                      <span>Rp. <?php echo number_format($cart['subtotal'],2,',','.'); ?></span>
                    </td>
                    <td>
                      <a href="<?php echo site_url().'/Shopping/delete/'.$cart['rowid']; ?>">
                        <img src="<?php echo base_url().'/assets/img/logo/delete.png'?>" width='15' height='15'></img>
                      </a>
                    </td>
                  </tr>
                  <? } ?>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>
                      <h5>Subtotal</h5>
                    </td>
                    <td>
                      <h5>Rp.<?php echo number_format($total,2,',','.'); ?></h5>
                    </td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>
                      <h5>Shipping cost</h5>
                    </td>
                    <td>
                      <h5>Free</h5>
                    </td>
                  </tr>
                  <tr class="shipping_area">
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>
                      <h5>Total Pay</h5>
                    </td>
                    <td>
                      <h5>Rp. <?php echo number_format($total,2,',','.'); ?></h5>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div class="checkout_btn_inner float-right">
                <a class="btn_1 checkout_btn_1" href="<? echo site_url().'/Checkout/'; ?>">Proceed to checkout</a>
              </div>
            </div>
          </div>
        </div>
      </section>