		<!-- Hero Area Start-->
		<div class="slider-area ">
			<div class="single-slider slider-height2 d-flex align-items-center">
				<div class="container">
					<div class="row">
						<div class="col-xl-12">
							<div class="hero-cap text-center">
								<h2>Profile</h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Hero Area End-->
		
		
		<!-- Start Align Area -->
		<div class="whole-wrap">
			<div class="container box_1170">
				<div class="section-top-border">					
					<center>
						<div class="col-lg-8 col-md-8">
							<h3 class="mb-30">Edit Profile</h3>
							<? //untuk membaca dan menampilkan data pelanggan; ?>
							<form action="<? echo site_url().'/Customer/edit' ?>" method="post">
								<div class="mt-10">
									<input type="text" id="txtnama" name="txtnama" placeholder="Username"
										onfocus="this.placeholder = ''" onblur="this.placeholder = 'Username'" required
										class="single-input"value="<? echo $pelanggan->nama; ?>" for="txtnama">
								</div>
								<div class="mt-10">
									<input type="text" id="txtnoktp" name="txtnoktp" placeholder="No KTP"
										onfocus="this.placeholder = ''" onblur="this.placeholder = 'No KTP'" required class="single-input" value="<? echo $pelanggan->noktp; ?>">
								</div>
								<div class="mt-10">
									<input type="email" id="txtemail" name="txtemail" placeholder="Email"
										onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" required class="single-input" for="txtemail" value="<? echo $pelanggan->email; ?>">
								</div>
								<div class="mt-10">
									<input type="text" id="txtprovinsi" name="txtprovinsi" placeholder="Province"
										onfocus="this.placeholder = ''" onblur="this.placeholder = 'Provinse'" required
										class="single-input" value="<? echo $pelanggan->provinsi; ?>">
								</div>
								<div class="mt-10">
									<input type="text" id="txtkota" name="txtkota" placeholder="City"
										onfocus="this.placeholder = ''" onblur="this.placeholder = 'City'" required
										class="single-input" value="<? echo $pelanggan->kota; ?>">
								</div>
								<div class="mt-10">
									<input type="text" for="txtalamat" id="txtalamat" name="txtalamat" placeholder="Address"
										onfocus="this.placeholder = ''" onblur="this.placeholder = 'Address'" required
										class="single-input" value="<? echo $pelanggan->alamat; ?>">
								</div>
								<div class="mt-10">
									<input type="text" id="txtkodepos" name="txtkodepos" placeholder="Postcode"
										onfocus="this.placeholder = ''" onblur="this.placeholder = 'Postcode'" required
										class="single-input" value="<? echo $pelanggan->kodepos; ?>">
								</div>
								<div class="mt-10">
									<input type="text" id="txttelp" name="txttelp" placeholder="Telp"
										onfocus="this.placeholder = ''" onblur="this.placeholder = 'Telp'" required
										class="single-input"  value="<?php echo $pelanggan->telp; ?>">
								</div>
								<div class="mt-10">
									<input type="submit" class="btn_1" value="simpan">
								</div>
							</form>
						</div>
					</center>
				</div>
			</div>
		</div>
		<!-- End Align Area -->