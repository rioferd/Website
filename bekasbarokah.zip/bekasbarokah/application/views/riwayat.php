<div class="slider-area ">
          <div class="single-slider slider-height2 d-flex align-items-center">
              <div class="container">
                  <div class="row">
                      <div class="col-xl-12">
                          <div class="hero-cap text-center">
                              <h2>History</h2>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <!--================Cart Area =================-->
      <section class="cart_area section_padding">
        <div class="container">
          <div class="cart_inner">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">ID Trans</th>
                    <th scope="col">Order Date</th>
                    <th scope="col">Total Pay</th>
                    <th scope="col">Pay Method</th>                   
                  </tr>
                </thead>
                <tbody>
                  <?php
                    $no=1;
                    $metode=array('COD','Transfer');
                    $status=array('Belum Dibayar','Menunggu Konfirmasi','Telah
                    Dibayar','Pengiriman', 'Selesai');
                    foreach($order as $data) {
                  ?>
                  <tr>
                    <td><?php echo $no; ?></td>
                    <td><span><?php echo $data->trans_id; ?></span></td>
                    <td><span><?php echo $data->tgl_order; ?></span></td>
                    <td><span><?php echo number_format($data->total_bayar,2,',','.'); ?></span></td>
                    <td><span><?php echo $metode[$data->metodebayar]; ?></span></td>
                  </tr>
                  <?php
                    $no++;
                  }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>