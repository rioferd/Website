<!-- Hero Area Start-->
        <div class="slider-area ">
            <div class="single-slider slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap text-center">
                                <h2>Checkout</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--================Checkout Area =================-->
        <div class="checkout_area section_padding">
          <div class="container">
            <div class="billing_details">
              <div class="row">
                <div class="col-lg-8">
                    <div class="checkout_details_area mt-50 clearfix">
                        <div class="cart-title">
                            <h2>Billing Details</h2>
                        </div>
                        <? //print_r($pelanggan); ?>
                        <form class="row contact_form" action="<?php echo site_url().'/Checkout/proses' ?>" method="post" name="frmcheckout">
                            <div class="row">
                                <div class="col-md-12 form-group p_star">
                                    <input type="text" for="txtnama" class="form-control" id="txtnama" name="txtnama" value="<?php echo $pelanggan->nama; ?>" placeholder="Name Customer" required readonly>
                                </div>
                                <div class="col-md-6 form-group p_star">
                                    <input type="email" class="form-control" for="txtemail" id="txtemail" name="txtemail" placeholder="Email" value="<?php echo $pelanggan->email; ?>" readonly required>
                                </div>
                                <div class="col-md-6 form-group p_star">
                                    <input type="text" class="form-control" id="txttelp" name="txttelp" placeholder="Phone Number" value="<?php echo $pelanggan->telp; ?>" readonly required>
                                </div>
                                <div class="col-md-6 form-group p_star">
                                    <input type="text" class="form-control" id="txtprovinsi" name="txtprovinsi" placeholder="Province" value="<?php echo $pelanggan->provinsi; ?>" required>
                                </div>
                                <div class="col-md-6 form-group p_star">
                                    <input type="text" class="form-control" id="txtkota" name="txtkota" placeholder="Town/City" value="<?php echo $pelanggan->kota; ?>" required>
                                </div>
                                <div class="col-md-12 form-group p_star">
                                    <input type="text" class="form-control" id="txtalamat" name="txtalamat" placeholder="Address" value="<?php echo $pelanggan->alamat; ?>" required>
                                </div>
                                <div class="col-md-12 form-group p_star">
                                    <input type="text" class="form-control" id="txtkodepos" name="txtkodepos" placeholder="Postcode" value="<?php echo $pelanggan->kodepos; ?>">
                                </div> 
                            </div> 
                        </div>
                    </div>
                    <div class="col-lg-4">
                    <?php 
                        $total=0;
                        foreach($cart_list as $cart){
                            $total=$total+$cart['subtotal'];
                        } 
                     ?>
                    <div class="order_box">
                        <h5>Cart Total</h5>
                        <ul class="list list_2">
                            <li><a>Subtotal :<span>Rp.<?php echo number_format($total,2,',','.'); ?></span></a></li>
                            <li><a>Shipping :<span>Free</span></a></li>
                            <li><a>Total :<span>Rp.<?php echo number_format($total,2,',','.'); ?></span></a></li>
                        </ul>
                        <div class="payment_item">
                         <!-- Cash on delivery -->
                            <div class="custom-control custom-checkbox mr-sm-2">
                            <input type="radio" class="form-check-input" id="rdmetode1" name="rdmetode" value="0">Cash On Delivery
                        </div>
                        <div class="custom-control custom-checkbox mr-sm-2">
                            <input type="radio" class="form-check-input" id="rdmetode2" name="rdmetode" value="1" checked>Transfer
                        </div>
                        </div>
                        <div class="cart-btn mt-50">
                            <input type="submit" class="btn_3" value="Checkout">
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--================End Checkout Area =================-->