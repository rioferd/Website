        <!-- Hero Area Start-->
        <div class="slider-area ">
            <div class="single-slider slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap text-center">
                                <h2>Regitration</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero Area End-->
        <!--================login_part Area =================-->
        <section class="login_part section_padding ">
            <div class="container">
                <center>
                    <div class="col-lg-6 col-md-6">
                        <div class="login_part_form">
                            <div class="login_part_form_iner">
                                <h3>Registration</h3>
                                <? if(isset($message)) {
                                    echo "<font color=red>".$message."</font>";
                                } ?>
                                <form class="row contact_form" action="<?php echo site_url().'/Login/registrasi_proses' ?>" method="post" novalidate="novalidate">
                                    <div class="col-md-12 form-group p_star">
                                        <input type="text" class="form-control" id="txtnama" name="txtuserid" for="txtuserid" value=""
                                            placeholder="Username" required="">
                                    </div>
                                    <div class="col-md-12 form-group p_star">
                                        <input type="email" class="form-control" for="txtemail" id="txtemail" name="txtemail" value=""
                                            placeholder="Email" required="">
                                    </div>
                                    <div class="col-md-12 form-group p_star">
                                        <input for="txtpassword"type="password" class="form-control" id="txtpassword" name="txtpassword" value=""
                                            placeholder="Password" required="">
                                    </div>
                                    <div class="col-md-12 form-group p_star">
                                        <input for="txtpassword" type="password" class="form-control" id="txtkonfirmasi" name="txtkonfirmasi" value=""
                                            placeholder="Confirm Password" required="">
                                    </div>
                                    <div class="col-md-12 form-group">
                                        <button type="submit" value="simpan" class="btn_1">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </center>
            </div>
        </section>
        <!--================login_part end =================-->
    </main>