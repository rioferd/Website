<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Bekas Barokah</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="<?php echo base_url(); ?>/site.webmanifest">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>/assets/img/favicon.ico">

    <!-- CSS here -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/flaticon.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/slicknav.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/animate.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/slick.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/nice-select.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css">
</head>
<?php
    if (isset($this->session->userdata['logged_in'])) {
        $iduser = ($this->session->userdata['logged_in']['userid']);
        $username = ($this->session->userdata['logged_in']['username']);
        $email = ($this->session->userdata['logged_in']['email']);
    } else {
    //header("location: ".base_url()."index.php");
    }
?>
<body>
    <header>
        <!-- Header Start -->
        <div class="header-area">
            <div class="main-header header-sticky">
                <div class="container-fluid">
                    <div class="menu-wrapper">
                        <!-- Logo -->
                        <div class="logo">
                            <a href="<? echo site_url().'/Home'; ?>"><img src="<?php echo base_url(); ?>/assets/img/logo/BekasBarokah.png" style="width: 70px;" alt=""></a>
                        </div>
                        <!-- Main-menu -->
                        <div class="main-menu d-none d-lg-block">
                            <nav>                                                
                                <ul id="navigation">  
                                    <li><a href="<? echo site_url().'/Home'; ?>">Home</a></li>
                                    <li><a href="<? echo site_url().'/Product'; ?>">Shop</a></li>
                                    <li><a href="<? echo site_url().'/Shopping'; ?>">Cart</a></li>
                                    <li><a href="<? echo site_url().'/Checkout'; ?>">Checkout</a></li>
                                    <? if (!isset($this->session->userdata['logged_in'])) { ?>
                                    <li><a href="<? echo site_url().'/Login'; ?>">Login</a></li>
                                    <? } else { ?>
                                    <li><a href="<? echo site_url().'/Customer/Profile'; ?>">Profile</a></li>
                                    <li><a href="<?php echo site_url().'/Riwayat'; ?>">Riwayat</a></li>
                                    <li><a href="<? echo site_url().'/Login/logout'; ?>">Logout</a></li>
                                    <? } ?>
                                </ul>
                            </nav>
                        </div>
                        <!-- Header Right -->
                        <div class="header-right">
                            <ul>
                                <li>
                                    <div class="nav-search search-switch">
                                        <span class="flaticon-search"></span>
                                    </div>
                                </li>
                                <li> <a href="<? echo site_url(). '/Login'; ?>"><span class="flaticon-user"></span></a></li>
                                <li><a href="<? echo site_url(). '/Shopping'; ?>"><span class="flaticon-shopping-cart">
                                 <?php
                                    if($this->cart->total_items()>0){
                                        echo $this->cart->total_items();
                                    } else {
                                        echo "(0)";
                                    }
                                ?>   
                                </span></a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Mobile Menu -->
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header End -->
    </header>
