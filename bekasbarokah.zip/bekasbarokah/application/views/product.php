    <!-- Hero Area Start-->
        <div class="slider-area ">
            <div class="single-slider slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap text-center">
                                <h2>Shop</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero Area End-->
        <!-- Latest Products Start -->
        <section class="popular-items latest-padding">
            <div class="container">
                <div class="row product-btn justify-content-between mb-40">
                    <div class="properties__button">
                    <!-- Select items -->
                    <div class="select-this">
                        <form action="">
                            <div class="select-itms">
                                <select name="select" id="select">
                                    <? foreach($kategori as $k) { ?>
                                    <option value=""><a href="<? echo site_url().'/Product/product_kategori/'.$k->kategori; ?>"><? echo $k->kategori; ?></a></option>
                                    <? } ?>
                                </select>
                            </div>
                        </form>
                    </div>
                </div>
                    <!-- Select items -->
                    <div class="select-this">
                        <form action="#">
                            
                        </form>
                    </div>
                </div>
                <!-- Nav Card -->
                <div class="tab-content" id="nav-tabContent">
                    <!-- card one -->
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                        <div class="row">
                            <?
                                foreach ($product as $p){
                            ?>
                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
                                <a href="<? echo site_url().'/Product/detail/'.$p->kode; ?>">
                                <div class="single-popular-items mb-50 text-center">
                                    <div class="popular-img">
                                        <img src="<? echo base_url().'product/'.$p->foto;?>" alt="">
                                        <div class="img-cap">
                                            <span src="<?php echo base_url().'product'.$p->foto;?>">View Detail</span>
                                        </div>
                                        <div class="favorit-items">
                                            <span class="flaticon-heart"></span>
                                        </div>
                                    </div>
                                    <div class="popular-caption">
                                        <h3><a href="product_details.html"><? echo $p->merk; ?></a></h3>
                                        <span>Rp. <? echo number_format($p->hargajual,2,',','.')?></span>
                                    </div>
                                </div>
                            </div>
                            <? 
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <!-- End Nav Card -->
            </div>
        </section>
        <!-- Latest Products End -->