<!-- Hero Area Start-->
      <div class="slider-area ">
          <div class="single-slider slider-height2 d-flex align-items-center">
              <div class="container">
                  <div class="row">
                      <div class="col-xl-12">
                          <div class="hero-cap text-center">
                              <h2>Checkout Report</h2>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <!--================ confirmation part start =================-->
        <section class="blog_area single-post-area section-padding">
         <div class="container">
            <div class="row">
               <div class="col-lg-8 posts-list">
                  <div class="single-post">
                     <div class="blog_details">
                        <p class="excert">
                           Bekas Barokah mengucapkan terima kasih atas pembelian yang telah anda lakukan. Bersama kami Berkas Barokah dengan slogan 𝕹𝖔 𝖙𝖍𝖗𝖎𝖋𝖙 𝖓𝖔 𝖕𝖆𝖗𝖙𝖞, kami sampaikan detail report transaksi anda yang telah anda lakukan :
                        </p>
                        <?php //print_r($order); ?>
                        <div class="col-lg-8">
                           <div class="order_box">
                              <ul class="list list_2">
                                 <li><a>Trans ID :<span><?php echo $order[0]->trans_id; ?></span></a></li>
                                 <li><a>ID/Name Customer :<span><?php echo $order[0]->id_plg.' / '.$order[0]->nama;?></span></a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="blog_details">
                        <p class="excert ">
                           Berikut ini detail item barang yang anda beli:
                        </p>
                     </div>
                     <table class="table">
                        <thead>
                           <tr>
                              <th scope="col">No</th>
                              <th scope="col">Merk</th>
                              <th scope="col">Price</th>
                              <th scope="col">Quantity</th>
                              <th scope="col">Total Pay</th>
                           </tr>
                        </thead>
                        <tbody>
                        <?php
                           $no=1;
                           foreach($order as $data){
                        ?>
                           <tr>
                              <td>
                                 <span><?php echo $no; ?></span>
                              </td>
                              <td>
                                 <a><?php echo $data->merk; ?></a>
                              </td>
                              <td>
                                 <span>Rp.<?php echo number_format($data->harga_jual,2,',','.');?></span>
                              </td>
                              <td>
                                 <span><?php echo $data->qty; ?></span>
                              </td>
                              <td>
                                 <span>Rp.<?php echo number_format($data->bayar,2,',','.'); ?></span>
                              </td>
                           </tr>
                           <?php $no++; } ?>
                        </tbody>
                     </table>
                     <div class="col-lg-8">
                        <div class="order_box">
                           <ul class="list list_2">
                              <li><a>Subtotal :<span>Rp. <?php echo number_format($order[0]->subtotal,2,',','.'); ?></span></a></li>
                              <li><a>Shipping :<span><?php echo $order[0]->ongkir; ?></span></a></li>
                              <li><a>Total Pay :<span>Rp. <?php echo number_format($order[0]->total_bayar,2,',','.'); ?></span></a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="blog_details">
                        <p class="excert ">
                           Pemesanan ini akan kami kirimkan pada :
                        </p>
                     </div>
                     <div class="col-lg-10">
                        <div class="order_box">
                           <ul class="list list_2">
                              <li><a>Address :<span><?php echo $order[0]->alamat_kirim; ?></span></a></li>
                              <li><a>City :<span><?php echo $order[0]->kota; ?></span></a></li>
                              <li><a>Province :<span><?php echo $order[0]->provinsi; ?></span></a></li>
                              <li><a>No Telp :<span><?php echo $order[0]->telp; ?></span></a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="blog_details">
                        <p class="excert ">
                           Ditunggu orderan berikutnya. Please enjoy it more ya~
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--================ confirmation part end =================-->
      