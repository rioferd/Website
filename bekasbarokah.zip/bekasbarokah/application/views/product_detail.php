<!-- Hero Area Start-->
        <div class="slider-area ">
            <div class="single-slider slider-height2 d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap text-center">
                                <h2>View Detail</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero Area End-->
        <!--================Single Product Area =================-->
        <!-- Product Details Area Start -->
        <?php
            $p=$product;    
        ?>
        
        
    <!-- Product Details Section Begin -->
    <section class="product_image_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div  class="product_img_slide owl-carousel">
                        <div class="single_product_img">
                            <img src="<?php echo base_url().'/product/'.$p->foto;?>" alt="">
                        </div>                        
                    </div>
                </div>
                
                
                <div class="col-lg-8">
                    <div class="single_product_text text-center">
                        <h3><?php echo $p->merk; ?></h3>
                        <p><?php echo $p->deskripsi; ?></p>
                        <!-- Add to Cart Form -->
                            
                            <?php 
                            if($p->stok<=0)
                            { $disabled="disabled"; }else{ $disabled="";}
                            ?>
                            <form class="card_area" method="post" action="<?php  echo site_url().'/Shopping/add/'?>">
                                <input type=hidden id='kode' name='kode' value="<?php echo $p->kode; ?>">
                                <div class="product_count_area">
                                    <p>Quantity</p>
                                    <div class="product_count d-inline-block">
                                        <span class="product_count_item inumber-decrement" onclick="var effect = document.getElementById('qty'); var qty = effect.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) effect.value--;return false;"><i class="fa fa-caret-down" aria-hidden="true"></i></span>
                                        <input type="number" class="qty-text" id="qty" step="1" min="1" max="300" name="qty" value="1">
                                        <span class="product_count_item number-increment" onclick="var effect = document.getElementById('qty'); var qty = effect.value; if( !isNaN( qty )) effect.value++;return false;"><i class="fa fa-caret-up" aria-hidden="true"></i></span>
                                    </div>
                                    <p>Rp. <?php echo number_format($p->hargajual,2,',','.');?></p>
                                </div>
                                <button type="submit" name="addtocart" value="5" class="btn_3" <?php echo $disabled; ?>>ADD TO CART</button>
                            </form>
                        </div>                    
                    </div>
                </div>
            </div>
        </section>
    <!-- Product Details Section End -->
        <!--================End Single Product Area =================-->