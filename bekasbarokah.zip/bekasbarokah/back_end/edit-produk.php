<?php 
	session_start();
	include 'db.php';
	if($_SESSION['status_login'] != true){
		echo '<script>window.location="login.php"</script>';
	}

	$produk = mysqli_query($conn, "SELECT * FROM web_barang WHERE kode = '".$_GET['id']."' ");
	if(mysqli_num_rows($produk) == 0){
		echo '<script>window.location="data-produk.php"</script>';
	}
	$p = mysqli_fetch_object($produk);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bekas Barokah</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
	<script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
</head>
<body>
	<!-- header -->
	<header style="background-color: #DAA520;">
		<div class="container">
			<h1><a href="dashboard.php">Bekas Barokah</a></h1>
			<ul>
				<li><a href="profil.php">Profil</a></li>
				<li><a href="data-kategori.php">Data Kategori</a></li>
				<li><a href="data-produk.php">Data Produk</a></li>
				<li><a href="keluar.php">Keluar</a></li>
			</ul>
		</div>
	</header>

	<!-- content -->
	<div class="section">
		<div class="container">
			<h3>Edit Data Produk</h3>
			<div class="box">
				<form action="" method="POST" enctype="multipart/form-data">
					<input type="text" name="kode" class="input-control" placeholder="Kode" value="<?php echo $p->kode ?>" required>
					<input type="text" name="merk" class="input-control" placeholder="Merk" value="<?php echo $p->merk ?>" required>
					<select class="input-control" name="kategori" required>
						<option value="">--Pilih--</option>
						<?php 
							$kategori = mysqli_query($conn, "SELECT * FROM web_kategori ORDER BY kategori DESC");
							while($r = mysqli_fetch_array($kategori)){
						?>
						<option value="<?php echo $r['kategori'] ?>" <?php echo ($r['id'] == $p->kategori)? 'selected':''; ?>><?php echo $r['kategori'] ?></option>
						<?php } ?>
					</select>
					<input type="text" name="satuan" class="input-control" placeholder="Satuan" value="<?php echo $p->satuan ?>" required>
					<input type="text" name="hargajual" class="input-control" placeholder="Harga Jual" value="<?php echo $p->hargajual ?>" required>
					<input type="text" name="stok" class="input-control" placeholder="Stok" value="<?php echo $p->stok ?>" required>
					<img src="product/<?php echo $p->foto ?>" width="100px">
					<input type="hidden" name="foto" value="<?php echo $p->foto ?>">
					<input type="file" name="gambar" class="input-control">
					<textarea class="input-control" name="deskripsi" placeholder="Deskripsi"><?php echo $p->deskripsi ?></textarea><br>
					
					<input type="submit" name="submit" style="background-color: #DAA520;" value="Submit" class="btn">
				</form>
				<?php 
					if(isset($_POST['submit'])){

						// data inputan dari form
						$kode 		= $_POST['kode'];
						$merk 		= $_POST['merk'];
						$kategori 	= $_POST['kategori'];
						$satuan 	= $_POST['satuan'];
						$hargajual	= $_POST['hargajual'];
						$stok 		= $_POST['stok'];
						$foto 	 	= $_POST['foto'];
						$deskripsi 	= $_POST['deskripsi'];
						$foto 	 	= $_POST['foto'];

						// data gambar yang baru
						$filename = $_FILES['gambar']['name'];
						$tmp_name = $_FILES['gambar']['tmp_name'];

						

						// jika admin ganti gambar
						if($filename != ''){
							$type1 = explode('.', $filename);
							$type2 = $type1[1];


							// menampung data format file yang diizinkan
							$tipe_diizinkan = array('jpg', 'jpeg', 'png', 'gif');

							// validasi format file
							if(!in_array($type2, $tipe_diizinkan)){
								// jika format file tidak ada di dalam tipe diizinkan
								echo '<script>alert("Format file tidak diizinkan")</scrtip>';

							}else{
								unlink('./product/'.$foto);
								move_uploaded_file($tmp_name, './product/'.$filename);
								$foto = $filename;
							}

						}else{
							// jika admin tidak ganti gambar
							$foto = $foto;
							
						}

						// query update data produk
						$update = mysqli_query($conn, "UPDATE web_barang SET
												kode = '".$kode."',
												merk = '".$merk."',
												kategori = '".$kategori."',
												satuan = '".$satuan."',
												hargajual = '".$hargajual."',
												stok = '".$stok."',												
												foto = '".$foto."',
												deskripsi = '".$deskripsi."'
												WHERE kode = '".$p->kode."'	");
						if($update){
							echo '<script>alert("Ubah data berhasil")</script>';
							echo '<script>window.location="data-produk.php"</script>';
						}else{
							echo 'gagal '.mysqli_error($conn);
						}
						
					}
				?>
			</div>
		</div>
	</div>

	<!-- footer -->
	<footer>
		<div class="container">
			<small>Copyright &copy; 2022 - Bekas Barokah.</small>
		</div>
	</footer>
	<script>
        CKEDITOR.replace( 'deskripsi' );
    </script>
</body>
</html>