<?php 
	
	include 'db.php';

	if(isset($_GET['idk'])){
		$delete = mysqli_query($conn, "DELETE FROM web_kategori WHERE id = '".$_GET['idk']."' ");
		echo '<script>window.location="data-kategori.php"</script>';
	}

	if(isset($_GET['idp'])){
		$produk = mysqli_query($conn, "SELECT foto FROM web_barang WHERE kode = '".$_GET['idp']."' ");
		$p = mysqli_fetch_object($produk);

		unlink('./product/'.$p->foto);

		$delete = mysqli_query($conn, "DELETE FROM web_barang WHERE kode = '".$_GET['idp']."' ");
		echo '<script>window.location="data-produk.php"</script>';
	}

?>