<?php 
	session_start();
	include 'db.php';
	if($_SESSION['status_login'] != true){
		echo '<script>window.location="login.php"</script>';
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bekas Barokah</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
	<script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
</head>
<body>
	<!-- header -->
	<header style="background-color: #DAA520;">
		<div class="container">
			<h1><a href="dashboard.php">Bekas Barokah</a></h1>
			<ul>
				<li><a href="profil.php">Profil</a></li>
				<li><a href="data-kategori.php">Data Kategori</a></li>
				<li><a href="data-produk.php">Data Produk</a></li>
				<li><a href="keluar.php">Keluar</a></li>
			</ul>
		</div>
	</header>

	<!-- content -->
	<div class="section">
		<div class="container">
			<h3>Tambah Data Produk</h3>
			<div class="box">
				<form action="" method="POST" enctype="multipart/form-data">
					<input type="text" name="kode" class="input-control" placeholder="Kode" required>
					<input type="text" name="merk" class="input-control" placeholder="Merk" required>
					<select class="input-control" name="kategori" required>
						<option value="">--Pilih--</option>
						<?php 
							$kategori = mysqli_query($conn, "SELECT * FROM web_kategori ORDER BY kategori DESC");
							while($r = mysqli_fetch_array($kategori)){
						?>
						
						<option value="<?php echo $r['id'] ?>"><?php echo $r['kategori'] ?></option>
						<?php } ?>
					</select>
					<input type="text" name="satuan" class="input-control" placeholder="Satuan" required>					
					<input type="text" name="hargajual" class="input-control" placeholder="Harga Jual" required>
					<input type="text" name="stok" class="input-control" placeholder="Stok" required>
					<input type="file" name="foto" class="input-control" required>
					<textarea class="input-control" name="deskripsi" placeholder="Deskripsi"></textarea><br>
					<input type="submit" name="submit" style="background-color: #DAA520;" value="Submit" class="btn">
				</form>
				<?php 
					if(isset($_POST['submit'])){

						// print_r($_FILES['gambar']);
						// menampung inputan dari form
						$kode 		= $_POST['kode'];
						$merk 		= $_POST['merk'];
						$kategori 	= $_POST['kategori'];
						$satuan 	= $_POST['satuan'];			
						$hargajual 	= $_POST['hargajual'];
						$stok 		= $_POST['stok'];
						$deskripsi 	= $_POST['deskripsi'];
						

						// menampung data file yang diupload
						$filename = $_FILES['foto']['name'];
						$tmp_name = $_FILES['foto']['tmp_name'];

						$type1 = explode('.', $filename);
						$type2 = $type1[1];
						
												
						// menampung data format file yang diizinkan
						$tipe_diizinkan = array('jpg', 'jpeg', 'png', 'gif');

						// validasi format file
						if(!in_array($type2, $tipe_diizinkan)){
							// jika format file tidak ada di dalam tipe diizinkan
							echo '<script>alert("Format file tidak diizinkan")</scrtip>';

						}else{
							// jika format file sesuai dengan yang ada di dalam array tipe diizinkan
							// proses upload file sekaligus insert ke database
							move_uploaded_file($tmp_name, './product/'.$filename);

							$insert = mysqli_query($conn, "INSERT INTO web_barang VALUES (
										'".$kode."',
										'".$merk."',
										'".$kategori."',
										'".$satuan."',
										'".$hargajual."',
										'".$stok."',
										'".$filename."',
										'".$deskripsi."'							
										) ");

							if($insert){
								echo '<script>alert("Tambah data berhasil")</script>';
								echo '<script>window.location="data-produk.php"</script>';
							}else{
								echo 'gagal '.mysqli_error($conn);
							}

						}

						
						
					}
				?>
			</div>
		</div>
	</div>

	<!-- footer -->
	<footer>
		<div class="container">
			<small>Copyright &copy; 2022 - Bekas Barokah.</small>
		</div>
	</footer>
	<script>
        CKEDITOR.replace( 'deskripsi' );
    </script>
</body>
</html>