-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Jan 2023 pada 06.53
-- Versi server: 10.4.20-MariaDB
-- Versi PHP: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bekasbarokah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `web_admin`
--

CREATE TABLE `web_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `admin_telp` varchar(20) DEFAULT NULL,
  `admin_email` varchar(50) DEFAULT NULL,
  `admin_address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `web_admin`
--

INSERT INTO `web_admin` (`admin_id`, `admin_name`, `username`, `password`, `admin_telp`, `admin_email`, `admin_address`) VALUES
(1, 'Vairuzia', 'Vairuzia', '81dc9bdb52d04dc20036dbd8313ed055', '0852-3408-9223', 'vairuziaadzra@gmail.com', 'Jln. Taman Bunga Raya A2/3A'),
(2, 'Royan', 'Royan', '81dc9bdb52d04dc20036dbd8313ed055', '085878117243', 'arroyanilyas87@gmail.com', 'Desa Parengan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `web_barang`
--

CREATE TABLE `web_barang` (
  `kode` char(10) NOT NULL,
  `merk` varchar(200) DEFAULT NULL,
  `kategori` char(30) DEFAULT NULL,
  `satuan` char(20) DEFAULT NULL,
  `hargajual` double DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `deskripsi` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `web_barang`
--

INSERT INTO `web_barang` (`kode`, `merk`, `kategori`, `satuan`, `hargajual`, `stok`, `foto`, `deskripsi`) VALUES
('A01', 'Zip Large Dickies', 'Hoodie', 'Unit', 160000, 5, 'zip.jpg', 'Size: L fit XL\r\nWarna: Maroon dan abu-abu\r\nBahan: Cotton lembut, kuat, dan tahan lama\r\nKondisi: 9/10\r\nNo Minus\r\nSize Chart:\r\n• Size M : Panjang 67 Lebar 52\r\n• Size L : Panjang 69 Lebar 54\r\n• Size XL : Panjang 71 Lebar 56\r\n• Size XXL : Panjang 73 Lebar 58'),
('A02', 'Dickies Care on Reverse', 'Hoodie', 'Unit', 176000, 7, 'reverse.jpg', 'Size: M\r\nWarna: Hijau daun\r\nBahan: Cotton polyester fleece\r\nKondisi: 9/10\r\nNo cacat\r\nSize Chart:\r\n• Size M : Panjang 67 Lebar 52\r\n• Size L : Panjang 69 Lebar 54\r\n• Size XL : Panjang 71 Lebar 56\r\n• Size XXL : Panjang 73 Lebar 58'),
('A03', 'WHO. A U', 'Crewneck', 'Unit', 140000, 3, 'whou.jpg', 'Size S (P 69 L 63)\r\nWarna: Abu-abu\r\nBahan: Baby Terry Cotton\r\nKondisi: 9/10'),
('A04', 'Adidas NEO ', 'Crewneck', 'Unit', 150000, 4, 'neo.jpg', 'Size M (P 85 L 93)\r\nWarna: Hitam\r\nBahan: Fleece Cotton\r\nKondisi: 8.9/10\r\n'),
('A05', 'MLB Yankees ', 'Crewneck', 'Unit', 158000, 2, 'mlb.jpg', 'Size M (P 71 L 64)\r\nWarna: Biru dongker dan Abu-abu\r\nBahan: Baby Terry PE\r\nKondisi: 9/10'),
('A06', 'Guess', 'Crewneck', 'Unit', 155000, 1, 'guess.jpg', 'Size XS fit M (P 53 L 69)\r\nWarna: Hijau botol\r\nBahan: Fleece Polyester\r\nKondisi: 9/10'),
('A07', 'Cap Comando', 'Topi', 'Unit', 24000, 4, 'comando.jpg', 'Warna: Biru jeans\r\nBahan: Rafel Denim\r\nKondisi: 8.5/10\r\nLingkar Kepala: 55-64 cm\r\nUkuran topi bisa di setel sesuai keinginan'),
('A08', 'Caps NYC 1984', 'Topi', 'Unit', 40000, 0, 'nyc.jpg', 'Warna: Putih tulang\r\nBahan: Drill Royal\r\nKondisi: 10/10\r\nLingkar Kepala: 54-62 cm\r\nUnisex\r\nUkuran topi bisa di setel sesuai keinginan'),
('A09', 'FUFB', 'Topi', 'Unit', 29000, 2, 'fufb.jpg', 'Warna: Hitam\r\nBahan: Kanvas Ring\r\nKondisi: 8.8/10\r\nLingkar Kepala: 55-62 cm\r\nUkuran topi bisa di setel sesuai keinginan'),
('A10', 'GAP Premium', 'Hoodie', 'Unit', 188000, 3, 'gap.jpg', 'Size: XL\r\nWarna: Biru dongker\r\nKondisi: 9/10\r\nBahan: Cotton fleece (tebal dan hangat)\r\nBerat: 600gm\r\nNyaman dan ringan dipakai\r\nBisa dipakai wanita / pria\r\nKeren dan Kekinian\r\nSize Chart:\r\n• Size M : Panjang 67 Lebar 52\r\n• Size L : Panjang 69 Lebar 54\r\n• Size XL : Panjang 71 Lebar 56\r\n• Size XXL : Panjang 73 Lebar 58'),
('A11', 'Adidas 3Foil Hood', 'Hoodie', 'Unit', 200000, 6, 'hood.jpg', 'Size: M fit L\r\nWarna: Biru dongker\r\nBahan: Cotton polyester fleece\r\nKondisi: 8/10\r\nNoda 3 titik kecil dilengan kiri\r\nNyaman dan ringan dipakai\r\nKeren dan Kekinian\r\nSize Chart:\r\n• Size M : Panjang 67 Lebar 52\r\n• Size L : Panjang 69 Lebar 54\r\n• Size XL : Panjang 71 Lebar 56\r\n• Size XXL : Panjang 73 Lebar 58'),
('A12', 'Snapback MIX MATCH LAYER', 'Topi', 'Unit', 30000, 0, 'snapback.jpg', 'Warna: Kuning\r\nBahan: Rafel Daimaru\r\nKondisi: 9/10\r\nLingkar Kepala: 56-65 cm\r\nNyaman dan trendy \r\nUkuran topi bisa di setel sesuai keinginan'),
('A13', 'Flanel Veterano ', 'Kemeja', 'Unit', 120000, 4, 'veterano.jpg', 'Size: L\r\nBahan: Katun\r\nKondisi: 9/10\r\nSize Chart\r\n• Size M ( Lebar Dada 50 cm x \r\nPanjang 70 cm )\r\n• Size L ( Lebar Dada 52 cm x \r\nPanjang 72 cm )\r\n• Size XL ( Lebar Dada 54 cm x \r\nPanjang 74 cm )\r\n'),
('A14', 'Whou Califdream', 'Kemeja', 'Unit', 125000, 2, 'califdream.jpg', 'Size: M fit L\r\nBahan: Katun\r\nKondisi: 9/10\r\nSize Chart\r\n• Size M ( Lebar Dada 50 cm x \r\nPanjang 70 cm )\r\n• Size L ( Lebar Dada 52 cm x \r\nPanjang 72 cm )\r\n• Size XL ( Lebar Dada 54 cm x \r\nPanjang 74 cm )\r\n'),
('A15', 'Uniqlo Spirit 1849', 'Kemeja', 'Unit', 118000, 4, 'uniqlo.jpg', 'Size: M fit L\r\nBahan: Katun\r\nKondisi: 9/10\r\nSize Chart\r\n• Size M ( Lebar Dada 50 cm x \r\nPanjang 70 cm )\r\n• Size L ( Lebar Dada 52 cm x \r\nPanjang 72 cm )\r\n• Size XL ( Lebar Dada 54 cm x \r\nPanjang 74 cm )'),
('A16', 'The Zara Man', 'Kemeja', 'Unit', 110000, 9, 'zara.jpg', 'Size: L \r\nBahan: Katun\r\nKondisi: 9/10\r\nSize Chart\r\n• Size M ( Lebar Dada 50 cm x \r\nPanjang 70 cm )\r\n• Size L ( Lebar Dada 52 cm x \r\nPanjang 72 cm )\r\n• Size XL ( Lebar Dada 54 cm x \r\nPanjang 74 cm )\r\n'),
('A17', 'Edwin', 'Jeans', 'Unit', 150000, 5, 'edwin.jpg', 'Ready Stok\r\nBahan: Soft Jeans\r\nSize: 31 32 (LP 76 P 91)\r\nKondisi: 9/10'),
('A18', 'Longpants G.U', 'Jeans', 'Unit', 134000, 4, 'longpants.jpg', 'Ready Stok\r\nBahan: Soft Jeans\r\nSize: 31 32 (LP 76 P 91)\r\nKondisi: 9/10'),
('A19', 'Hamo Premium', 'Jeans', 'Unit', 165000, 2, 'hamo.jpg', '<p>Ready Stok Bahan: Soft Jeans Size: 29 30 (LP 71 P 87) Kondisi: 9/10</p>\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `web_kategori`
--

CREATE TABLE `web_kategori` (
  `id` int(11) NOT NULL,
  `kategori` char(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `web_kategori`
--

INSERT INTO `web_kategori` (`id`, `kategori`) VALUES
(1, 'Jeans'),
(2, 'Kemeja'),
(3, 'Hoodie'),
(4, 'Crewneck'),
(5, 'Topi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `web_order`
--

CREATE TABLE `web_order` (
  `trans_id` char(100) NOT NULL,
  `id_plg` char(20) DEFAULT NULL,
  `tgl_order` date DEFAULT NULL,
  `subtotal` double DEFAULT NULL,
  `ongkir` double DEFAULT NULL,
  `total_bayar` double DEFAULT NULL,
  `alamat_kirim` varchar(100) DEFAULT NULL,
  `kota` varchar(30) DEFAULT NULL,
  `provinsi` varchar(30) DEFAULT NULL,
  `kodepos` varchar(20) DEFAULT NULL,
  `metodebayar` int(11) DEFAULT NULL,
  `buktibayar` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `web_order`
--

INSERT INTO `web_order` (`trans_id`, `id_plg`, `tgl_order`, `subtotal`, `ongkir`, `total_bayar`, `alamat_kirim`, `kota`, `provinsi`, `kodepos`, `metodebayar`, `buktibayar`, `status`) VALUES
('3-13072022-032025', '3', '2022-07-13', 864000, 0, 864000, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-13072022-055625', '3', '2022-07-13', 0, 0, 0, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-13072022-055644', '3', '2022-07-13', 176000, 0, 176000, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-13072022-055753', '3', '2022-07-13', 0, 0, 0, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-13072022-055947', '3', '2022-07-13', 158000, 0, 158000, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-13072022-064514', '3', '2022-07-13', 150000, 0, 150000, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-13072022-065314', '3', '2022-07-13', 176000, 0, 176000, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-13072022-065658', '3', '2022-07-13', 149000, 0, 149000, 'Jln. Parengan RT. 03 RW. 04', 'Lamongan', 'Jawa Timur', '34333', 0, NULL, NULL),
('3-14072022-030117', '3', '2022-07-14', 318000, 0, 318000, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-14072022-091039', '3', '2022-07-14', 336000, 0, 336000, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-28072022-014829', '3', '2022-07-28', 376000, 0, 376000, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL),
('3-28072022-015006', '3', '2022-07-28', 160000, 0, 160000, 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `web_order_detail`
--

CREATE TABLE `web_order_detail` (
  `trans_id` char(100) NOT NULL,
  `kode_brg` char(20) NOT NULL,
  `harga_jual` double DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `bayar` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `web_order_detail`
--

INSERT INTO `web_order_detail` (`trans_id`, `kode_brg`, `harga_jual`, `qty`, `bayar`) VALUES
('3-13072022-032025', 'A01', 160000, 1, 160000),
('3-13072022-032025', 'A02', 176000, 4, 704000),
('3-13072022-055644', 'A02', 176000, 1, 176000),
('3-13072022-055947', 'A05', 158000, 1, 158000),
('3-13072022-064514', 'A04', 150000, 1, 150000),
('3-13072022-065314', 'A02', 176000, 1, 176000),
('3-13072022-065658', 'A07', 24000, 1, 24000),
('3-13072022-065658', 'A14', 125000, 1, 125000),
('3-14072022-030117', 'A01', 160000, 1, 160000),
('3-14072022-030117', 'A05', 158000, 1, 158000),
('3-14072022-091039', 'A01', 160000, 1, 160000),
('3-14072022-091039', 'A02', 176000, 1, 176000),
('3-28072022-014829', 'A10', 188000, 2, 376000),
('3-28072022-015006', 'A01', 160000, 1, 160000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `web_pelanggan`
--

CREATE TABLE `web_pelanggan` (
  `id` int(11) NOT NULL,
  `nama` varchar(200) DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `kota` char(100) DEFAULT NULL,
  `provinsi` char(100) DEFAULT NULL,
  `kodepos` char(20) DEFAULT NULL,
  `email` char(100) DEFAULT NULL,
  `telp` char(20) DEFAULT NULL,
  `userID` char(20) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `noktp` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `web_pelanggan`
--

INSERT INTO `web_pelanggan` (`id`, `nama`, `alamat`, `kota`, `provinsi`, `kodepos`, `email`, `telp`, `userID`, `PASSWORD`, `noktp`) VALUES
(3, 'Vairuzia Adzra', 'Jl. Taman Bunga Raya A2/3a, Kedungpane, Kec. Mijen', 'Semarang', 'Jawa Tengah', '62261', 'vairuziaadzra@gmail.com', '085803637521', 'Vairuzia', 'bbfb4d8633f6fe45aeea28a6a3eaabe9', '3374155705020003'),
(5, 'Vairuzia Adzra', NULL, NULL, NULL, NULL, 'vairuziaadzra@gmail.com', NULL, 'Vairuzia Adzra', '25d55ad283aa400af464c76d713c07ad', NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `web_admin`
--
ALTER TABLE `web_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indeks untuk tabel `web_barang`
--
ALTER TABLE `web_barang`
  ADD PRIMARY KEY (`kode`);

--
-- Indeks untuk tabel `web_kategori`
--
ALTER TABLE `web_kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `web_order`
--
ALTER TABLE `web_order`
  ADD PRIMARY KEY (`trans_id`);

--
-- Indeks untuk tabel `web_order_detail`
--
ALTER TABLE `web_order_detail`
  ADD PRIMARY KEY (`trans_id`,`kode_brg`);

--
-- Indeks untuk tabel `web_pelanggan`
--
ALTER TABLE `web_pelanggan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `web_admin`
--
ALTER TABLE `web_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `web_kategori`
--
ALTER TABLE `web_kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `web_pelanggan`
--
ALTER TABLE `web_pelanggan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
